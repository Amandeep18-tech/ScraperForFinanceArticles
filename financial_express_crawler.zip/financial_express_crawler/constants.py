sqs_queue_name = "nlp-finance-india"
chrome_driver_path = "./webdriver/chromedriver"